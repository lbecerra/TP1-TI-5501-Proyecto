﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    [Authorize(Roles = ("cliente"))]
    public class ClientesController : Controller
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();
        //
        // GET: /Clientes/
        public ActionResult Index()
        {
            return View(db.users.ToList());
        }
	}
}