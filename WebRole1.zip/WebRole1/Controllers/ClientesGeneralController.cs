﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class ClientesGeneralController : Controller
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

        // GET: /ClientesGeneral/
        public ActionResult Index()
        {
            var cliente = db.CLIENTE.Include(c => c.PERSONA);
            if (User.IsInRole("admin"))
            {

                var variable2 = from mem in db.CLIENTE.Include(c => c.PERSONA)
                                join cli in db.MEMBRESIA_POR_CLIENTE.Include(m => m.CLIENTE).Include(m => m.MEBRESIA)
                                on new { mem.INT_NUMERO_CLIENTE } equals new { cli.INT_NUMERO_CLIENTE }
                                select cli.INT_NUMERO_CLIENTE;

                var variable1 = from s in cliente
                                where !(variable2.Contains(s.INT_NUMERO_CLIENTE))
                                select s;

                var variable4 = variable1.ToList();

                return View(variable4);
            }

            else if (User.IsInRole("instructor"))
            {

                return View(cliente.ToList());
            }

            return View(cliente.ToList());
        }

        // GET: /ClientesGeneral/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CLIENTE cliente = db.CLIENTE.Find(id);
            if (cliente == null)
            {
                return HttpNotFound();
            }
            return View(cliente);
        }

        // GET: /ClientesGeneral/Create
        public ActionResult Create()
        {
            ViewBag.STR_CEDULA = new SelectList(db.PERSONA, "STR_CEDULA", "STR_APELLIDO1");
            return View();
        }

        // POST: /ClientesGeneral/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="INT_NUMERO_CLIENTE,STR_CEDULA,DT_FECHA_INGRESO")] CLIENTE cliente)
        {
            if (ModelState.IsValid)
            {
                db.CLIENTE.Add(cliente);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.STR_CEDULA = new SelectList(db.PERSONA, "STR_CEDULA", "STR_APELLIDO1", cliente.STR_CEDULA);
            return View(cliente);
        }

        // GET: /ClientesGeneral/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CLIENTE cliente = db.CLIENTE.Find(id);
            if (cliente == null)
            {
                return HttpNotFound();
            }
            ViewBag.STR_CEDULA = new SelectList(db.PERSONA, "STR_CEDULA", "STR_APELLIDO1", cliente.STR_CEDULA);
            return View(cliente);
        }

        // POST: /ClientesGeneral/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="INT_NUMERO_CLIENTE,STR_CEDULA,DT_FECHA_INGRESO")] CLIENTE cliente)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cliente).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.STR_CEDULA = new SelectList(db.PERSONA, "STR_CEDULA", "STR_APELLIDO1", cliente.STR_CEDULA);
            return View(cliente);
        }

        // GET: /ClientesGeneral/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CLIENTE cliente = db.CLIENTE.Find(id);
            if (cliente == null)
            {
                return HttpNotFound();
            }
            return View(cliente);
        }

        // POST: /ClientesGeneral/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CLIENTE cliente = db.CLIENTE.Find(id);
            db.CLIENTE.Remove(cliente);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
