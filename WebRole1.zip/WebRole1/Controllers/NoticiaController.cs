﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebRole1.Interface;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class NoticiaController : Controller, IObservable
    {
        private IObservador ObservadorNoticias = new NoticiaClienteController();
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

        // GET: /Noticia/
        public ActionResult Index()
        {
            return View(db.NOTICIA.ToList());
        }

        // GET: /Noticia/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NOTICIA noticia = db.NOTICIA.Find(id);
            if (noticia == null)
            {
                return HttpNotFound();
            }
            return View(noticia);
        }

        // GET: /Noticia/Create
        public ActionResult Create()
        {
            return View();
        }


        public void Notificar(string noticia)
        {

            ObservadorNoticias.Actualizar(noticia);

        }

        // POST: /Noticia/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="Id_Noticia,Descripcion,Fecha")] NOTICIA noticia)
        {
            if (ModelState.IsValid)
            {
                noticia.Fecha = DateTime.Now;
                db.NOTICIA.Add(noticia);
                db.SaveChanges();
                Notificar(noticia.Descripcion);
                return RedirectToAction("Index");
            }

            return View(noticia);
        }

        // GET: /Noticia/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NOTICIA noticia = db.NOTICIA.Find(id);
            if (noticia == null)
            {
                return HttpNotFound();
            }
            return View(noticia);
        }

        // POST: /Noticia/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id_Noticia,Descripcion,Fecha")] NOTICIA noticia)
        {
            if (ModelState.IsValid)
            {
                db.Entry(noticia).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(noticia);
        }

        // GET: /Noticia/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NOTICIA noticia = db.NOTICIA.Find(id);
            if (noticia == null)
            {
                return HttpNotFound();
            }
            return View(noticia);
        }

        // POST: /Noticia/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            NOTICIA noticia = db.NOTICIA.Find(id);
            db.NOTICIA.Remove(noticia);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
