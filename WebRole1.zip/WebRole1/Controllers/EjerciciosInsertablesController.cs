﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class EjerciciosInsertablesController : Controller
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

       

        // GET: /EjeciciosInsertables/
        public ActionResult Index(int? id)
        {
            var ejercicio = db.EJERCICIO.Include(e => e.MAQUINA);


            RUTINA rutina = db.RUTINA.Find(id);

            var ejerutina = new EJERCICIO_POR_RUTINA();
            ejerutina.INT_ID_RUTINA = id.Value;
            
            var tuple = new Tuple<IEnumerable<EJERCICIO>, RUTINA, EJERCICIO, EJERCICIO_POR_RUTINA>(ejercicio, rutina, new EJERCICIO(), ejerutina);
            return View(tuple);
        }

        // GET: /EjeciciosInsertables/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EJERCICIO ejercicio = db.EJERCICIO.Find(id);
            if (ejercicio == null)
            {
                return HttpNotFound();
            }
            return View(ejercicio);
        }

        // GET: /EjeciciosInsertables/Create
        public ActionResult Create()
        {
            ViewBag.INT_ID_MAQUINA = new SelectList(db.MAQUINA, "INT_ID_MAQUINA", "STR_NOMBRE_MAQUINA");
            return View();
        }

        // POST: /EjeciciosInsertables/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(int? id, [Bind(Include = "INT_NUMERO_CLIENTE,STR_NOMBRE_RUTINA,INT_DURACION_TOTAL")] RUTINA rutina)
        {
            if (ModelState.IsValid)
            {
                rutina.INT_NUMERO_CLIENTE = id;
                db.RUTINA.Add(rutina);
                db.SaveChanges();
                return RedirectToAction("Details", "EjerciciosInsertables", rutina.INT_ID_RUTINA);
            }

            ViewBag.INT_NUMERO_CLIENTE = new SelectList(db.CLIENTE, "INT_NUMERO_CLIENTE", "STR_CEDULA", rutina.INT_NUMERO_CLIENTE);
            return View(rutina);
        }

        // GET: /EjeciciosInsertables/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EJERCICIO ejercicio = db.EJERCICIO.Find(id);
            if (ejercicio == null)
            {
                return HttpNotFound();
            }
            ViewBag.INT_ID_MAQUINA = new SelectList(db.MAQUINA, "INT_ID_MAQUINA", "STR_NOMBRE_MAQUINA", ejercicio.INT_ID_MAQUINA);
            return View(ejercicio);
        }

        // POST: /EjeciciosInsertables/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="INT_ID_EJERCICIO,STR_NOMBRE_EJERCICIO,IMG_EJERCICIO,STR_VIDEO,STR_DESCRIPCION,INT_ID_MAQUINA")] EJERCICIO ejercicio)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ejercicio).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.INT_ID_MAQUINA = new SelectList(db.MAQUINA, "INT_ID_MAQUINA", "STR_NOMBRE_MAQUINA", ejercicio.INT_ID_MAQUINA);
            return View(ejercicio);
        }

        // GET: /EjeciciosInsertables/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EJERCICIO ejercicio = db.EJERCICIO.Find(id);
            if (ejercicio == null)
            {
                return HttpNotFound();
            }
            return View(ejercicio);
        }

        // POST: /EjeciciosInsertables/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EJERCICIO ejercicio = db.EJERCICIO.Find(id);
            db.EJERCICIO.Remove(ejercicio);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
