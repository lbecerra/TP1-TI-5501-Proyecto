﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class UsuariosController : Controller
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

        // GET: /Usuarios/
        public ActionResult Index()
        {
            var users = db.users.Include(u => u.PERSONA);
            return View(users.ToList());
        }

        // GET: /Usuarios/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            users users = db.users.Find(id);
            if (users == null)
            {
                return HttpNotFound();
            }
            return View(users);
        }

        // GET: /Usuarios/Create
        public ActionResult Create()
        {
            string[] array = { "Administrador", "Instructor"};
            var list = new SelectList(array);
            ViewBag.ROL = list;
            return View();
        }

        // POST: /Usuarios/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(string ced, [Bind(Include="Id,UserName,PasswordHash,SecurityStamp,Discriminator,STR_CEDULA")] users users)
        {
            if (ModelState.IsValid)
            {
                users.STR_CEDULA = ced;
                db.users.Add(users);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            string[] array = { "Administrador", "Instructor" };
            var list = new SelectList(array);
            ViewBag.ROL = list;
            return View(users);
        }

        // GET: /Usuarios/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            users users = db.users.Find(id);
            if (users == null)
            {
                return HttpNotFound();
            }
            ViewBag.STR_CEDULA = new SelectList(db.PERSONA, "STR_CEDULA", "STR_APELLIDO1", users.STR_CEDULA);
            return View(users);
        }

        // POST: /Usuarios/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,UserName,PasswordHash,SecurityStamp,Discriminator,STR_CEDULA")] users users)
        {
            if (ModelState.IsValid)
            {
                db.Entry(users).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.STR_CEDULA = new SelectList(db.PERSONA, "STR_CEDULA", "STR_APELLIDO1", users.STR_CEDULA);
            return View(users);
        }

        // GET: /Usuarios/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            users users = db.users.Find(id);
            if (users == null)
            {
                return HttpNotFound();
            }
            return View(users);
        }

        // POST: /Usuarios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            users users = db.users.Find(id);
            db.users.Remove(users);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
