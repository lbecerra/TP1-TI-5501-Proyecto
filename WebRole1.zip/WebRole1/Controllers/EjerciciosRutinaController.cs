﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class EjerciciosRutinaController : Controller
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

        // GET: /EjerciciosRutina/
        public ActionResult Index(int? id)
        {
            var ejercicio_por_rutina = from s in db.EJERCICIO_POR_RUTINA.Include(e => e.EJERCICIO).Include(e => e.RUTINA) 
                           where s.INT_ID_RUTINA == id
                           select s;

            //var ejercicio_por_rutina = db.EJERCICIO_POR_RUTINA.Include(e => e.EJERCICIO).Include(e => e.RUTINA);
            return View(ejercicio_por_rutina.ToList());
        }

        // GET: /EjerciciosRutina/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EJERCICIO_POR_RUTINA ejercicio_por_rutina = db.EJERCICIO_POR_RUTINA.Find(id);
            if (ejercicio_por_rutina == null)
            {
                return HttpNotFound();
            }
            return View(ejercicio_por_rutina);
        }

        // GET: /EjerciciosRutina/Create
        public ActionResult Create()
        {
            ViewBag.INT_ID_EJERCICIO = new SelectList(db.EJERCICIO, "INT_ID_EJERCICIO", "STR_NOMBRE_EJERCICIO");
            ViewBag.INT_ID_RUTINA = new SelectList(db.RUTINA, "INT_ID_RUTINA", "STR_NOMBRE_RUTINA");
            return View();
        }

        // POST: /EjerciciosRutina/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(int id, int id2, [Bind(Include = "INT_ID_RUTINA,INT_ID_EJERCICIO,DT_FECHA_MOD,FT_DURACION,FT_REPETICIONES,FT_PESO,FT_DESCANSO,FT_SERIES")] EJERCICIO_POR_RUTINA ejercicio_por_rutina)
        {
            if (ModelState.IsValid)
            {
                ejercicio_por_rutina.INT_ID_EJERCICIO = id;
                ejercicio_por_rutina.INT_ID_RUTINA = id2;
                db.EJERCICIO_POR_RUTINA.Add(ejercicio_por_rutina);
                db.SaveChanges();
                return RedirectToAction("Index", "EjerciciosInsertables", new { id = id2});
            }

            ViewBag.INT_ID_EJERCICIO = new SelectList(db.EJERCICIO, "INT_ID_EJERCICIO", "STR_NOMBRE_EJERCICIO", ejercicio_por_rutina.INT_ID_EJERCICIO);
            ViewBag.INT_ID_RUTINA = new SelectList(db.RUTINA, "INT_ID_RUTINA", "STR_NOMBRE_RUTINA", ejercicio_por_rutina.INT_ID_RUTINA);
            return View(ejercicio_por_rutina);
        }

        // GET: /EjerciciosRutina/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EJERCICIO_POR_RUTINA ejercicio_por_rutina = db.EJERCICIO_POR_RUTINA.Find(id);
            if (ejercicio_por_rutina == null)
            {
                return HttpNotFound();
            }
            ViewBag.INT_ID_EJERCICIO = new SelectList(db.EJERCICIO, "INT_ID_EJERCICIO", "STR_NOMBRE_EJERCICIO", ejercicio_por_rutina.INT_ID_EJERCICIO);
            ViewBag.INT_ID_RUTINA = new SelectList(db.RUTINA, "INT_ID_RUTINA", "STR_NOMBRE_RUTINA", ejercicio_por_rutina.INT_ID_RUTINA);
            return View(ejercicio_por_rutina);
        }

        // POST: /EjerciciosRutina/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="INT_ID_RUTINA,INT_ID_EJERCICIO,DT_FECHA_MOD,FT_DURACION,FT_REPETICIONES,FT_PESO,FT_DESCANSO,FT_SERIES")] EJERCICIO_POR_RUTINA ejercicio_por_rutina)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ejercicio_por_rutina).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.INT_ID_EJERCICIO = new SelectList(db.EJERCICIO, "INT_ID_EJERCICIO", "STR_NOMBRE_EJERCICIO", ejercicio_por_rutina.INT_ID_EJERCICIO);
            ViewBag.INT_ID_RUTINA = new SelectList(db.RUTINA, "INT_ID_RUTINA", "STR_NOMBRE_RUTINA", ejercicio_por_rutina.INT_ID_RUTINA);
            return View(ejercicio_por_rutina);
        }

        // GET: /EjerciciosRutina/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EJERCICIO_POR_RUTINA ejercicio_por_rutina = db.EJERCICIO_POR_RUTINA.Find(id);
            if (ejercicio_por_rutina == null)
            {
                return HttpNotFound();
            }
            return View(ejercicio_por_rutina);
        }

        // POST: /EjerciciosRutina/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EJERCICIO_POR_RUTINA ejercicio_por_rutina = db.EJERCICIO_POR_RUTINA.Find(id);
            db.EJERCICIO_POR_RUTINA.Remove(ejercicio_por_rutina);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
