﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class AvanceUsuarioController : Controller
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

        // GET: /AvanceUsuario/
        public ActionResult Index()
        {
            var con = from mem in db.CLIENTE.Include(c => c.PERSONA)
                      join cli in db.users
                      on mem.STR_CEDULA equals cli.STR_CEDULA
                      where cli.Id == User.Identity.Name
                      select mem.INT_NUMERO_CLIENTE;

            //var conee = con.ToList();


            //var iksa = medida_por_cliente.ToList();

            var medida = from m in db.MEDIDA
                         where con.Contains(m.INT_NUMERO_CLIENTE.Value)
                         orderby m.DT_FECHA_MEDIDA descending
                         select m;

            var Medidas = medida.ToList();
            return View(Medidas);
        }

        // GET: /AvanceUsuario/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MEDIDA medida = db.MEDIDA.Find(id);
            if (medida == null)
            {
                return HttpNotFound();
            }
            return View(medida);
        }

        // GET: /AvanceUsuario/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /AvanceUsuario/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="INT_ID_MEDIDA,DT_FECHA_MEDIDA,DB_ALTURA,DB_IMC,DB_BICDER,DB_BICIZQ,DB_CINTURA,INT_EDAD,DB_ESPALDA,DB_MUSLO_DER,DB_MUSLO_IZQ,DB_PECHO,DB_PESO,DB_PORCENTAJE_GRASA,DB_CADERA")] MEDIDA medida)
        {
            if (ModelState.IsValid)
            {
                db.MEDIDA.Add(medida);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(medida);
        }

        // GET: /AvanceUsuario/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MEDIDA medida = db.MEDIDA.Find(id);
            if (medida == null)
            {
                return HttpNotFound();
            }
            return View(medida);
        }

        // POST: /AvanceUsuario/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="INT_ID_MEDIDA,DT_FECHA_MEDIDA,DB_ALTURA,DB_IMC,DB_BICDER,DB_BICIZQ,DB_CINTURA,INT_EDAD,DB_ESPALDA,DB_MUSLO_DER,DB_MUSLO_IZQ,DB_PECHO,DB_PESO,DB_PORCENTAJE_GRASA,DB_CADERA")] MEDIDA medida)
        {
            if (ModelState.IsValid)
            {
                db.Entry(medida).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(medida);
        }

        // GET: /AvanceUsuario/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MEDIDA medida = db.MEDIDA.Find(id);
            if (medida == null)
            {
                return HttpNotFound();
            }
            return View(medida);
        }

        // POST: /AvanceUsuario/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            MEDIDA medida = db.MEDIDA.Find(id);
            db.MEDIDA.Remove(medida);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
