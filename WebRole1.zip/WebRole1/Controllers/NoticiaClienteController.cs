﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebRole1.Interface;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class NoticiaClienteController : Controller, IObservador
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

        // GET: /NoticiaCliente/
        public ActionResult Index()
        {
            return View(db.NOTICIAS_CLIENTE.ToList());
        }

        // GET: /NoticiaCliente/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NOTICIAS_CLIENTE noticias_cliente = db.NOTICIAS_CLIENTE.Find(id);
            if (noticias_cliente == null)
            {
                return HttpNotFound();
            }
            return View(noticias_cliente);
        }

        public void Actualizar(String Noticia)
        {
            NOTICIAS_CLIENTE NewNoticia = new NOTICIAS_CLIENTE();
            NewNoticia.STR_DESCRIPCION = Noticia;
            NewNoticia.DT_FECHA_NOTICIA = DateTime.Now;

            Create(NewNoticia);

        }

        // GET: /NoticiaCliente/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /NoticiaCliente/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(NOTICIAS_CLIENTE noticias_cliente)
        {
            if (ModelState.IsValid)
            {
                db.NOTICIAS_CLIENTE.Add(noticias_cliente);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(noticias_cliente);
        }

        // GET: /NoticiaCliente/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NOTICIAS_CLIENTE noticias_cliente = db.NOTICIAS_CLIENTE.Find(id);
            if (noticias_cliente == null)
            {
                return HttpNotFound();
            }
            return View(noticias_cliente);
        }

        // POST: /NoticiaCliente/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="INT_ID_NOTICIA_CLIENTE,STR_DESCRIPCION,DT_FECHA_NOTICIA")] NOTICIAS_CLIENTE noticias_cliente)
        {
            if (ModelState.IsValid)
            {
                db.Entry(noticias_cliente).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(noticias_cliente);
        }

        // GET: /NoticiaCliente/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            NOTICIAS_CLIENTE noticias_cliente = db.NOTICIAS_CLIENTE.Find(id);
            if (noticias_cliente == null)
            {
                return HttpNotFound();
            }
            return View(noticias_cliente);
        }

        // POST: /NoticiaCliente/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            NOTICIAS_CLIENTE noticias_cliente = db.NOTICIAS_CLIENTE.Find(id);
            db.NOTICIAS_CLIENTE.Remove(noticias_cliente);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
