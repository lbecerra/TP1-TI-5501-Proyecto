﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PagedList;
using WebRole1.Models;

namespace WebRole1.Controllers
{
    public class MembresiaClientesController : Controller
    {
        private bj_gimnasioEntities db = new bj_gimnasioEntities();

        // GET: /MembresiaClientes/
        public ActionResult Index(string Sorting_Order, string Search_Data, string Filter_Value, int? Page_No)
        {

            ViewBag.SortingName = String.IsNullOrEmpty(Sorting_Order) ? "Name_Description" : "";
            ViewBag.SortingDate = Sorting_Order == "Date_Enroll" ? "Date_Description" : "Date";
            ViewBag.FilterValue = Search_Data;
            if (Search_Data != null)
            {
                Page_No = 1;
            }
            else
            {
                Search_Data = Filter_Value;
            }

            var membresia_por_cliente = from stu in db.MEMBRESIA_POR_CLIENTE.Include(m => m.CLIENTE).Include(m => m.MEBRESIA) select stu;

            if (Search_Data != null && Search_Data != "")
            {
                membresia_por_cliente = membresia_por_cliente.Where(stu => stu.CLIENTE.PERSONA.STR_APELLIDO1.ToUpper().Contains(Search_Data.ToUpper())
                    || stu.CLIENTE.PERSONA.STR_NOMBRE.ToUpper().Contains(Search_Data.ToUpper())
                    || stu.CLIENTE.STR_CEDULA.ToUpper().Contains(Search_Data.ToUpper()));

            }
            else
            {
                membresia_por_cliente = membresia_por_cliente.Where(stu => true);

            }
            switch (Sorting_Order)
            {
                case "Date":
                    membresia_por_cliente = membresia_por_cliente.OrderBy(stu => stu.INT_FECHA_PAGO);
                    break;
                case "Date_Description":
                    membresia_por_cliente = membresia_por_cliente.OrderByDescending(stu => stu.INT_FECHA_PAGO);
                    break;
                default:
                    membresia_por_cliente = membresia_por_cliente.OrderBy(stu => stu.INT_FECHA_PAGO);
                    break;
            }

            membresia_por_cliente = membresia_por_cliente.OrderBy(stu => stu.CLIENTE.PERSONA.STR_NOMBRE);
            int Size_Of_Page = 10;
            int No_Of_Page = (Page_No ?? 1);


            return View(membresia_por_cliente.ToPagedList(No_Of_Page, Size_Of_Page));

        }

        // GET: /MembresiaClientes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MEMBRESIA_POR_CLIENTE membresia_por_cliente = db.MEMBRESIA_POR_CLIENTE.Find(id);
            if (membresia_por_cliente == null)
            {
                return HttpNotFound();
            }
            return View(membresia_por_cliente);
        }

        public ActionResult Morosidad(int? id, int? id2)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //ESTE ES EL DE MOROSIDAD
            MEMBRESIA_POR_CLIENTE membresia_por_cliente = db.MEMBRESIA_POR_CLIENTE.Find(id, id2);
            if (membresia_por_cliente == null)
            {
                return HttpNotFound();
            }
            return View(membresia_por_cliente);
        }


        // GET: /MembresiaClientes/Create
        public ActionResult Create()
        {
            ViewBag.INT_NUMERO_CLIENTE = new SelectList(db.CLIENTE, "INT_NUMERO_CLIENTE", "STR_CEDULA");
            ViewBag.INT_IDMEMBRESIA = new SelectList(db.MEBRESIA, "INT_IDMEMBRESIA", "STR_NOMBRE_MEMBRESIA");
            return View();
        }

        // POST: /MembresiaClientes/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(int? id, [Bind(Include = "INT_NUMERO_CLIENTE,INT_IDMEMBRESIA,DB_PRECIO,DB_MONTO_PENDIENTE,INT_NUM_RECIBO,INT_FECHA_PAGO,STR_OBSERVACIONES")] MEMBRESIA_POR_CLIENTE membresia_por_cliente)
        {

            if (ModelState.IsValid)
            {
                var fecha = from s in db.MEBRESIA
                            where s.INT_IDMEMBRESIA == membresia_por_cliente.INT_IDMEMBRESIA
                            select s.INT_PERIODO.Value;

                var concha = DateTime.Now.AddMonths(fecha.ToList().ElementAt(0));

                membresia_por_cliente.INT_NUMERO_CLIENTE = id.Value;
                membresia_por_cliente.INT_FECHA_PAGO = concha;

                db.MEMBRESIA_POR_CLIENTE.Add(membresia_por_cliente);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.INT_IDMEMBRESIA = new SelectList(db.MEBRESIA, "INT_IDMEMBRESIA", "STR_NOMBRE_MEMBRESIA", membresia_por_cliente.INT_IDMEMBRESIA);
            return View(membresia_por_cliente);
        }

        // GET: /MembresiaClientes/Edit/5
        public ActionResult Edit(int? id, int? id2)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MEMBRESIA_POR_CLIENTE membresia_por_cliente = db.MEMBRESIA_POR_CLIENTE.Find(id, id2);
            if (membresia_por_cliente == null)
            {
                return HttpNotFound();
            }
            ViewBag.INT_NUMERO_CLIENTE = new SelectList(db.CLIENTE, "INT_NUMERO_CLIENTE", "STR_CEDULA", membresia_por_cliente.INT_NUMERO_CLIENTE);
            ViewBag.INT_IDMEMBRESIA = new SelectList(db.MEBRESIA, "INT_IDMEMBRESIA", "STR_NOMBRE_MEMBRESIA", membresia_por_cliente.INT_IDMEMBRESIA);
            var fecha = System.DateTime.Today;
            membresia_por_cliente.INT_FECHA_PAGO = DateTime.Parse(fecha.ToShortDateString());
            return View(membresia_por_cliente);
        }

        // POST: /MembresiaClientes/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="INT_NUMERO_CLIENTE,INT_IDMEMBRESIA,DB_PRECIO,DB_MONTO_PENDIENTE,INT_NUM_RECIBO,INT_FECHA_PAGO,STR_OBSERVACIONES")] MEMBRESIA_POR_CLIENTE membresia_por_cliente)
        {
            if (ModelState.IsValid)
            {
                db.Entry(membresia_por_cliente).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.INT_NUMERO_CLIENTE = new SelectList(db.CLIENTE, "INT_NUMERO_CLIENTE", "STR_CEDULA", membresia_por_cliente.INT_NUMERO_CLIENTE);
            ViewBag.INT_IDMEMBRESIA = new SelectList(db.MEBRESIA, "INT_IDMEMBRESIA", "STR_NOMBRE_MEMBRESIA", membresia_por_cliente.INT_IDMEMBRESIA);
            return View(membresia_por_cliente);
        }

        // GET: /MembresiaClientes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MEMBRESIA_POR_CLIENTE membresia_por_cliente = db.MEMBRESIA_POR_CLIENTE.Find(id);
            if (membresia_por_cliente == null)
            {
                return HttpNotFound();
            }
            return View(membresia_por_cliente);
        }

        // POST: /MembresiaClientes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            MEMBRESIA_POR_CLIENTE membresia_por_cliente = db.MEMBRESIA_POR_CLIENTE.Find(id);
            db.MEMBRESIA_POR_CLIENTE.Remove(membresia_por_cliente);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
